import unittest
from app.analyzer.ocr_processor import OCRProcessor
import os


class TestOCRProcessor(unittest.TestCase):
    def setUp(self):
        self.ocr_processor = OCRProcessor()
        current_dir = os.path.dirname(os.path.abspath(__file__))
        self.test_image_path = os.path.join(current_dir, 'images', 'sample_complaint.png')

    def test_process_image(self):
        with open(self.test_image_path, 'rb') as f:
            result = self.ocr_processor.process_image(f)

        self.assertIsInstance(result, dict)

        if 'error' in result:
            self.assertIsInstance(result['error'], str)
        else:
            self.assertTrue(result.get('success'))
            self.assertIsInstance(result.get('text'), str)

    def test_error_handling(self):
        # None 대신 빈 파일 객체 사용
        class EmptyFile:
            def read(self):
                return b""

        result = self.ocr_processor.process_image(EmptyFile())
        self.assertIn('error', result)


if __name__ == '__main__':
    unittest.main()