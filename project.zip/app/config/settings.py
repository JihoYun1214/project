class Settings:
    def __init__(self):
        # Flask settings
        self.SECRET_KEY = 'your-secret-key'
        self.DEBUG = True

        # OCR API settings
        self.OCR_API_URL = "https://7uwnwj16mq.apigw.ntruss.com/custom/v1/35597/01aa3772f98373db119137dac208f7de997e3269139cc8e1dfd8ab8cc53c896b/general"
        self.OCR_CLIENT_ID = "gvabjddihi"  # 실제 발급받은 Client ID
        self.OCR_CLIENT_SECRET = "UHJxWG94Y0xJSmJsV1hPbVNKckVwSkZqS2ZPTXhwYmY="  # 실제 발급받은 Secret Key

        # Database settings
        self.DATABASE_URL = 'sqlite:///legal_analysis.db'


