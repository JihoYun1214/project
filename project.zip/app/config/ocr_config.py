# OCR API 설정
OCR_CONFIG = {
    'API_URL': 'https://7uwnwj16mq.apigw.ntruss.com/custom/v1/35597/01aa3772f98373db119137dac208f7de997e3269139cc8e1dfd8ab8cc53c896b/general',  # 네이버에서 받은 API URL
    'SECRET_KEY': 'UGVqRmhoaHJ3eHlXZE1zamR6a1paUXZuQ0RteWFqalg='  # 네이버에서 받은 Secret Key
}

# 지원하는 이미지 형식
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}

# 최대 파일 크기 (5MB)
MAX_FILE_SIZE = 5 * 1024 * 1024