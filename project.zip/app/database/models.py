from sqlalchemy import Column, Integer, String, Float, DateTime, Text
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()


class Case(Base):
    __tablename__ = 'cases'

    id = Column(Integer, primary_key=True)
    case_number = Column(String(50), unique=True)
    court = Column(String(100))
    date = Column(DateTime)
    category = Column(String(50))
    content = Column(Text)
    result = Column(String(20))
    compensation = Column(Float, nullable=True)


class LegalTerm(Base):
    __tablename__ = 'legal_terms'

    id = Column(Integer, primary_key=True)
    term = Column(String(100))
    category = Column(String(50))
    description = Column(Text)


class AnalysisResult(Base):
    __tablename__ = 'analysis_results'

    id = Column(Integer, primary_key=True)
    document_hash = Column(String(64), unique=True)
    analysis_date = Column(DateTime)
    success_probability = Column(Float)
    compensation_estimate = Column(Float)
    summary = Column(Text)
    key_points = Column(Text)
    similar_cases = Column(Text)