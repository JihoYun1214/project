from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()

def init_db():
    engine = create_engine('sqlite:///legal_analysis.db')
    Base.metadata.create_all(engine)
    return sessionmaker(bind=engine)